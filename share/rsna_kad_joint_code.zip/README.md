# RSNA Knee: team kernel code (Szymon, 2026-10-14)

Team-internal code. Please don't share it outside the team.

## What's here

| File | What it is |
|---|---|
| `kaggle_inference.py` | Our model's inference (main_v5_C: 6 ConvNeXtV2-Tiny @384, 5-view, full-data seeds; LB 0.948 alone). Reads the competition data from `/kaggle/input`, writes a submission CSV. The `/raid/...` defaults at the top are our server paths, overridden on Kaggle. |
| `v2stack/blend_template.py` | Our current best kernel (LB 0.957): runs our model, then heliosli's public R7 notebook (Raptor CoAtNet 384 + compact ConvNeXt-S R7, 50/50), and rank-blends 0.3 ours / 0.7 R7 per finding. If the R7 part fails, our file is submitted alone. |
| `v2stack/build_kernel.py` | Builds that kernel: embeds our script and the R7 notebook's cells (unchanged except its start time) into one file. |
| `joint/joint_template.py` | The **joint team kernel**: runs the 0.957 kernel above (leg V), then your inference (leg P), and rank-blends them per finding (default 0.5 / 0.5). |
| `joint/build_joint.py` | Builds the joint kernel from your `.py` or `.ipynb` (`--partner-src`) plus the dataset slugs it needs (`--partner-datasets`). |
| `joint/standin_partner.py` | The stand-in we tested the joint kernel with; shows the contract your code has to meet. |

## The contract for your part (leg P)

- It runs **unchanged**, as its own Python process, with working directory `/kaggle/working`, offline (no internet).
  In a notebook, lines starting with `!` or `%` are commented out, so pip installs must come from attached wheels.
- It reads the test data from `/kaggle/input/competitions/rsna-knee-abnormality-detection/` and your weights from
  your dataset under `/kaggle/input/datasets/<owner>/<slug>/`.
- Whatever it leaves in `/kaggle/working/submission.csv` is its output: the standard format, every test study, 12
  finding columns. Any scores work, since the blend uses per-finding ranks.
- It may clean up `/kaggle/working`. Our output is saved elsewhere before your part starts.

## Safety

- **Your part fails:** if it crashes, exceeds its time cap, misses a study, or produces non-finite or constant
  columns, it is dropped and our 0.957 file is submitted.
- **Our part fails:** the reverse also holds; your file is submitted alone.
- **Shared time budget:** both parts share one 8.6 h budget (9 h Kaggle limit).

## Tests run

We ran it on the 58 gold studies in a fake `/kaggle` tree, with a stand-in for your model. Five scenarios passed:

- both legs, ours first;
- both legs, yours first;
- your part crashes;
- your part misses a study;
- your part times out.

## What we need from you to go live

1. Your weights as a private Kaggle dataset shared with `sroziews`.
2. The exact notebook or script you submit.
3. Its runtime on the hidden test set (T4).
4. Whether it needs a different Kaggle environment than the default pinned one. One kernel can only use one image.
