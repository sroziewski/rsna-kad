"""Build qa/joint/kernel_joint/: our v3stack kernel + the partner's inference code (qa/joint, 2026-10-14).

The inner kernel is a built qa/v2stack/build_kernel.py output (default the v3stack one that scored 0.957), embedded
verbatim except its start time, which is taken from the joint wrapper (JOINT_T0) so both legs share one 9 h budget.
The partner source is a .py run as is, or an .ipynb whose code cells are joined; notebook-only lines (`!`, `%`) are
commented out and listed in the build output.  `--fake ROOT` rewrites /kaggle/ and '/tmp paths for the gold-58 test;
the inner kernel must then be one built with the same --fake.
"""
import argparse
import base64
import hashlib
import json
import zlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
INNER_T0 = "T0 = time.time()\n"
INNER_T0_PATCH = "T0 = float(os.environ.get('JOINT_T0') or time.time())  # [joint] shared 9 h budget\n"

ap = argparse.ArgumentParser()
ap.add_argument("--partner-src", required=True, help="partner inference .py or .ipynb")
ap.add_argument("--partner-datasets", nargs="+", default=[], help="Kaggle datasets the partner code reads")
ap.add_argument("--inner", default=str(ROOT / "qa/v3stack/kernel_blend/blend_v2stack.py"))
ap.add_argument("--inner-meta", default=str(ROOT / "qa/v3stack/kernel_blend/kernel-metadata.json"),
                help="its kernel-metadata.json: dataset sources and docker image are carried over")
ap.add_argument("--w-partner", type=float, default=0.5)
ap.add_argument("--partner-first", action="store_true")
ap.add_argument("--partner-max-h", type=float, default=8.0)
ap.add_argument("--kernel-id", default="sroziews/rsna-kad-joint")
ap.add_argument("--docker-image", help="override the inner kernel's pinned image")
ap.add_argument("--fake", help="test tree root replacing /kaggle and /tmp")
ap.add_argument("--out", default=str(HERE / "kernel_joint"))
a = ap.parse_args()


def fake(text):
    if not a.fake:
        return text
    return text.replace("/kaggle/", a.fake + "/").replace("'/tmp", f"'{a.fake}/tmp")


inner = Path(a.inner).read_text()
assert inner.count(INNER_T0) == 1, "inner kernel start-time line not found exactly once"
inner = inner.replace(INNER_T0, INNER_T0_PATCH)
src = Path(a.partner_src)
raw = src.read_bytes()
if src.suffix == ".ipynb":
    cells = ["".join(c["source"]) for c in json.loads(raw)["cells"] if c["cell_type"] == "code"]
    lines = []
    for ln in "\n\n".join(cells).splitlines():
        if ln.lstrip().startswith(("!", "%")):
            print("  [joint] commented out:", ln.strip()[:120])
            ln = "# [joint] " + ln
        lines.append(ln)
    partner = "\n".join(lines) + "\n"
else:
    partner = raw.decode()
partner = fake(partner)


def packed(s):
    # Kaggle rejects script kernels over ~1 MB (HTTP 400 on push): plain base64 of v3stack + partner was 1.19 MB
    return base64.b64encode(zlib.compress(s.encode(), 9)).decode()


text = (fake((HERE / "joint_template.py").read_text())
        .replace("@@INNER_MD5@@", hashlib.md5(inner.encode()).hexdigest())
        .replace("@@PARTNER_NAME@@", src.name)
        .replace("@@PARTNER_SHA@@", hashlib.sha256(raw).hexdigest())
        .replace("@@W_PARTNER@@", repr(a.w_partner))
        .replace("@@PARTNER_FIRST@@", repr(a.partner_first))
        .replace("@@PARTNER_MAX_S@@", repr(round(a.partner_max_h * 3600)))
        .replace("@@INNER_B64@@", packed(inner))
        .replace("@@PARTNER_B64@@", packed(partner)))
assert "@@" not in text.replace(packed(inner), "").replace(packed(partner), "")
inner_meta = json.loads(Path(a.inner_meta).read_text())
out = Path(a.out)
out.mkdir(parents=True, exist_ok=True)
(out / "joint.py").write_text(text)
(out / "partner_src.py").write_text(partner)  # readable copy for review; the kernel embeds it
meta = {
    "id": a.kernel_id,
    "title": a.kernel_id.split("/")[1],
    "code_file": "joint.py",
    "language": "python",
    "kernel_type": "script",
    "is_private": True,
    "enable_gpu": True,
    "enable_tpu": False,
    "enable_internet": False,
    "dataset_sources": list(dict.fromkeys(inner_meta["dataset_sources"] + a.partner_datasets)),
    "competition_sources": ["rsna-knee-abnormality-detection"],
    "kernel_sources": [],
    "model_sources": [],
    "docker_image": a.docker_image or inner_meta["docker_image"],
    "machine_shape": "NvidiaTeslaT4",
}
(out / "kernel-metadata.json").write_text(json.dumps(meta, indent=1))
print("built", out / "joint.py", len(text), "bytes; inner md5", hashlib.md5(inner.encode()).hexdigest(),
      "; partner", src.name, "; joint md5", hashlib.md5(text.encode()).hexdigest())
